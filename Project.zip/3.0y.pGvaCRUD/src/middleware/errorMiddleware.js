const logger = require('../utils/logger');

const errorMiddleware = (err, req, res, next) => {
    // Log the error for debugging purposes
    logger.error(err.message || 'Internal Server Error');

    // Extract error details
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Internal Server Error';

    // Send error response to the client
    res.status(statusCode).json({
        success: false,
        message,
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack }), // Include stack trace in development mode
    });
};

module.exports = errorMiddleware;