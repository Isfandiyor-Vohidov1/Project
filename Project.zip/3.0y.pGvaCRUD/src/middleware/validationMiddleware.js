import joi from 'joi';

const validate = (schema) => {
    return (req, res, next) => {
        const { error } = schema.validate(req.body || req.query || req.params, { abortEarly: false });

        if (error) {
            const errorMessage = error.details.map((detail) => detail.message).join(', ');
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errorMessage,
            });
        }
        next();
    };
};

module.exports = validate;
