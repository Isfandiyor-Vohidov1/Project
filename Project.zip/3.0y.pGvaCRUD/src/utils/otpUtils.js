const otpMap = {};

const generateOTP = (userId) => {
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    otpMap[userId] = otp;
    return otp;
};

const verifyOTP = (userId, otp) => {
    return otpMap[userId] === otp;
};

module.exports = { generateOTP, verifyOTP };