const db = require('../config/db');

class Post {
    static async create(postData) {
        return db('posts').insert(postData).returning('*');
    }

    static async getAll() {
        return db('posts').select('*');
    }

    static async getById(id) {
        return db('posts').where({ id }).first();
    }

    static async update(id, postData) {
        return db('posts').where({ id }).update(postData).returning('*');
    }

    static async delete(id) {
        return db('posts').where({ id }).del();
    }
}

module.exports = Post;