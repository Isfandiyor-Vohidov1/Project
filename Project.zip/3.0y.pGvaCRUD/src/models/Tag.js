const db = require('../config/db');

class Tag {
    static async create(tagData) {
        return db('tags').insert(tagData).returning('*');
    }

    static async getAll() {
        return db('tags').select('*');
    }

    static async getById(id) {
        return db('tags').where({ id }).first();
    }

    static async update(id, tagData) {
        return db('tags').where({ id }).update(tagData).returning('*');
    }

    static async delete(id) {
        return db('tags').where({ id }).del();
    }
}

module.exports = Tag;