const db = require('../config/db');

class Author {
    static async create(authorData) {
        return db('authors').insert(authorData).returning('*');
    }

    static async getAll() {
        return db('authors').select('*');
    }

    static async getById(id) {
        return db('authors').where({ id }).first();
    }

    static async update(id, authorData) {
        return db('authors').where({ id }).update(authorData).returning('*');
    }

    static async delete(id) {
        return db('authors').where({ id }).del();
    }
}

module.exports = Author;