const db = require('../config/db');

class Category {
    static async create(categoryData) {
        return db('categories').insert(categoryData).returning('*');
    }

    static async getAll() {
        return db('categories').select('*');
    }

    static async getById(id) {
        return db('categories').where({ id }).first();
    }

    static async update(id, categoryData) {
        return db('categories').where({ id }).update(categoryData).returning('*');
    }

    static async delete(id) {
        return db('categories').where({ id }).del();
    }
}

module.exports = Category;