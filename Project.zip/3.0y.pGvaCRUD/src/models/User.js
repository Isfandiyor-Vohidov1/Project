import bcrypt from 'bcrypt';
const db = require('../config/db');

class User {
    static async create(userData) {
        const hashedPassword = await bcrypt.hash(userData.password, 10);
        return db('users')
            .insert({ ...userData, password: hashedPassword })
            .returning('*');
    }

    static async getByEmail(email) {
        return db('users').where({ email }).first();
    }

    static async getById(id) {
        return db('users').where({ id }).first();
    }

    static async comparePassword(password, hashedPassword) {
        return bcrypt.compare(password, hashedPassword);
    }
}

module.exports = User;