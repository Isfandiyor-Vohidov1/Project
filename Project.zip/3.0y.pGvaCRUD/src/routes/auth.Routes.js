import express from "express";
const { signup, verifyOTP, signin, refreshToken } = require('../controllers/authController');

const router = express.Router();

router.post('/signup', signup);
router.post('/verify-otp', verifyOTP);
router.post('/signin', signin);
router.post('/refresh-token', refreshToken);

module.exports = router;