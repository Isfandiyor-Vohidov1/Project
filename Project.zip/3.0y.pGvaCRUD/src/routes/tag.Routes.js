import express from 'express';
const {
    createTag,
    getAllTags,
    getTagById,
    updateTag,
    deleteTag,
} = require('../controllers/tagController');
const authMiddleware = require('../middlewares/authMiddleware');

const router = express.Router();

router.post('/', authMiddleware, createTag);
router.get('/', authMiddleware, getAllTags);
router.get('/:id', authMiddleware, getTagById);
router.put('/:id', authMiddleware, updateTag);
router.delete('/:id', authMiddleware, deleteTag);

module.exports = router;