const Post = require('../models/Post');

exports.createPost = async (req, res) => {
    try {
        const { title, content, authorId, tags, categoryId, status } = req.body;
        const newPost = await Post.create({
            title,
            content,
            authorId,
            tags,
            categoryId,
            status,
        });
        res.status(201).json({ postId: newPost[0].id, message: 'Post created' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAllPosts = async (req, res) => {
    try {
        const posts = await Post.getAll();
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getPostById = async (req, res) => {
    try {
        const { id } = req.params;
        const post = await Post.getById(id);
        if (!post) return res.status(404).json({ message: 'Post not found' });
        res.status(200).json(post);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updatePost = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedPost = await Post.update(id, req.body);
        if (!updatedPost.length) return res.status(404).json({ message: 'Post not found' });
        res.status(200).json({ postId: updatedPost[0].id, message: 'Post updated' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.deletePost = async (req, res) => {
    try {
        const { id } = req.params;
        const deleted = await Post.delete(id);
        if (!deleted) return res.status(404).json({ message: 'Post not found' });
        res.status(200).json({ message: 'Post deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};