const Tag = require('../models/Tag');

exports.createTag = async (req, res) => {
    try {
        const { name } = req.body;
        const newTag = await Tag.create({ name });
        res.status(201).json({ tagId: newTag[0].id, message: 'Tag created' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAllTags = async (req, res) => {
    try {
        const tags = await Tag.getAll();
        res.status(200).json(tags);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getTagById = async (req, res) => {
    try {
        const { id } = req.params;
        const tag = await Tag.getById(id);
        if (!tag) return res.status(404).json({ message: 'Tag not found' });
        res.status(200).json(tag);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateTag = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedTag = await Tag.update(id, req.body);
        if (!updatedTag.length) return res.status(404).json({ message: 'Tag not found' });
        res.status(200).json({ tagId: updatedTag[0].id, message: 'Tag updated' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.deleteTag = async (req, res) => {
    try {
        const { id } = req.params;
        const deleted = await Tag.delete(id);
        if (!deleted) return res.status(404).json({ message: 'Tag not found' });
        res.status(200).json({ message: 'Tag deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};