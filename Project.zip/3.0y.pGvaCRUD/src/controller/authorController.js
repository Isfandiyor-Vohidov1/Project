const Author = require('../models/Author');

exports.createAuthor = async (req, res) => {
    try {
        const { name, bio, avatar } = req.body;
        const newAuthor = await Author.create({ name, bio, avatar });
        res.status(201).json({ authorId: newAuthor[0].id, message: 'Author created' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAllAuthors = async (req, res) => {
    try {
        const authors = await Author.getAll();
        res.status(200).json(authors);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAuthorById = async (req, res) => {
    try {
        const { id } = req.params;
        const author = await Author.getById(id);
        if (!author) return res.status(404).json({ message: 'Author not found' });
        res.status(200).json(author);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateAuthor = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedAuthor = await Author.update(id, req.body);
        if (!updatedAuthor.length) return res.status(404).json({ message: 'Author not found' });
        res.status(200).json({ authorId: updatedAuthor[0].id, message: 'Author updated' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.deleteAuthor = async (req, res) => {
    try {
        const { id } = req.params;
        const deleted = await Author.delete(id);
        if (!deleted) return res.status(404).json({ message: 'Author not found' });
        res.status(200).json({ message: 'Author deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};